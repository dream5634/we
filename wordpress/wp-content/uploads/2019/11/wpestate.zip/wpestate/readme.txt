Theme Name: Wp Estate
Theme URI: http://demos.wpestatetheme.org/
Description:WP Estate is a premium & responsive WordPress theme designed for Real Estate companies and independent agents.
Version: 5.2.1
Author:  wpestate - https://themeforest.net/user/wpestate
Author URI: 
Text Domain: wpestate
Tags: white, one-column, two-columns,left-sidebar, right-sidebar, fluid-layout , custom-menu, theme-options, translation-ready
License: 
License URI:

For help files go here http://helpv4.wpestatetheme.org/