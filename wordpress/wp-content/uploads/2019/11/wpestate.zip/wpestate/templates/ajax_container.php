<?php $show_compare=1;?>
<span class="entry-title listing_loader_title"><?php esc_html_e('Your search results','wpestate');?></span>
<div class="loader" id="listing_loader_maps"></div>     
<div id="listing_ajax_container">
</div>
